"""
Atlas question-answering engine for ATLAS.
"""
import re
from typing import Any, List, Dict, Optional
from atlas.schemas import Domain, RecordRef, Answer
from atlas.graph import StudyGraph
from atlas.reasoning import (
    find_hys_law_candidates, check_hys_law_exclusions, get_monitor_decision,
    find_prohibited_meds, find_dosing_errors, find_visit_window_deviations,
    find_saes, count_subjects_by_arm, count_sites, find_discontinued_subjects
)


class Atlas:
    """Question-answering engine over the study graph."""
    
    def __init__(self, graph: StudyGraph):
        self.graph = graph
        if not graph._built:
            graph.build()
    
    def answer(self, question: str) -> Answer:
        """Answer a natural language question about the study."""
        question_lower = question.lower()
        qid = self._generate_question_id(question)
        
        # Route to appropriate handler based on question type
        if 'hy\'s law' in question_lower or 'hys law' in question_lower:
            return self._answer_hys_law(question, qid)
        elif 'prohibited' in question_lower and 'medication' in question_lower:
            return self._answer_prohibited_meds(question, qid)
        elif 'dosing error' in question_lower or 'dose error' in question_lower:
            return self._answer_dosing_errors(question, qid)
        elif 'visit window' in question_lower or 'protocol deviation' in question_lower:
            return self._answer_visit_deviations(question, qid)
        elif 'serious adverse' in question_lower or 'sae' in question_lower:
            return self._answer_saes(question, qid)
        elif 'discontinued' in question_lower or 'discontinuation' in question_lower:
            return self._answer_discontinued(question, qid)
        # Lab threshold finding questions (e.g., "ALT > 1000", "bilirubin > 2xULN")
        elif any(x in question_lower for x in ['alt', 'ast', 'bilirubin', 'bili', 'hba1c', 'glucose', 'creatinine', 'creat']) and \
             any(x in question_lower for x in ['>', '<', 'above', 'below', 'greater', 'less', 'exceed', 'high', 'low', 'uln', 'xuln', '×uln']):
            return self._answer_lab_finding(question, qid)
        elif ('count' in question_lower or 'how many' in question_lower or 'number of' in question_lower) and 'subject' in question_lower:
            return self._answer_count_subjects(question, qid)
        elif ('count' in question_lower or 'how many' in question_lower or 'number of' in question_lower) and 'site' in question_lower:
            return self._answer_count_sites(question, qid)
        elif 'subject' in question_lower and ('detail' in question_lower or 'profile' in question_lower or '360' in question_lower):
            return self._answer_patient360(question, qid)
        else:
            return self._answer_general(question, qid)
    
    def _generate_question_id(self, question: str) -> str:
        """Generate a question ID."""
        import hashlib
        return f"Q_{hashlib.md5(question.encode()).hexdigest()[:8]}"
    
    def _answer_hys_law(self, question: str, qid: str) -> Answer:
        """Answer Hy's law related questions."""
        candidates = find_hys_law_candidates(self.graph)
        
        # Filter by exclusions
        valid_candidates = []
        for c in candidates:
            if not check_hys_law_exclusions(self.graph, c):
                decision, reason = get_monitor_decision(self.graph, c['usubjid'])
                c['monitor_decision'] = decision
                c['monitor_reason'] = reason
                valid_candidates.append(c)
        
        if 'how many' in question.lower() or 'count' in question.lower():
            answer = len(valid_candidates)
            evidence = []
            for c in valid_candidates:
                evidence.extend([c['alt_rec'].ref, c['ast_rec'].ref, c['bili_rec'].ref])
            return Answer(qid, answer, evidence, {'candidates': valid_candidates})
        
        elif 'which subject' in question.lower() or 'list' in question.lower():
            answer = [c['usubjid'] for c in valid_candidates]
            evidence = []
            for c in valid_candidates:
                evidence.extend([c['alt_rec'].ref, c['ast_rec'].ref, c['bili_rec'].ref])
            return Answer(qid, answer, evidence, {'candidates': valid_candidates})
        
        elif 'monitor' in question.lower() or 'adjudicat' in question.lower():
            # Return monitor decisions
            results = []
            for c in valid_candidates:
                results.append({
                    'usubjid': c['usubjid'],
                    'decision': c['monitor_decision'],
                    'reason': c['monitor_reason']
                })
            evidence = []
            for c in valid_candidates:
                evidence.extend([c['alt_rec'].ref, c['ast_rec'].ref, c['bili_rec'].ref])
            return Answer(qid, results, evidence, {})
        
        return Answer(qid, [], [], {})
    
    def _answer_prohibited_meds(self, question: str, qid: str) -> Answer:
        """Answer prohibited medication questions."""
        # Extract subject if specified
        usubjid_match = re.search(r'(042-S\d{2}-\d{3})', question)
        if usubjid_match:
            usubjid = usubjid_match.group(1)
            protocol_version = self._get_protocol_version(usubjid)
            meds = find_prohibited_meds(self.graph, usubjid, protocol_version)
            evidence = [m.ref for m in meds]
            answer = [{'usubjid': usubjid, 'medication': m.parsed.get('cmtrt'), 'class': m.parsed.get('cmclas'), 'start': str(m.parsed.get('cmstdtc'))} for m in meds]
            return Answer(qid, answer, evidence, {})
        
        # All subjects
        results = []
        evidence = []
        for subj in self.graph.records_by_subject:
            protocol_version = self._get_protocol_version(subj)
            meds = find_prohibited_meds(self.graph, subj, protocol_version)
            for m in meds:
                results.append({
                    'usubjid': subj,
                    'medication': m.parsed.get('cmtrt'),
                    'class': m.parsed.get('cmclas'),
                    'start': str(m.parsed.get('cmstdtc'))
                })
                evidence.append(m.ref)
        return Answer(qid, results, evidence, {})
    
    def _answer_dosing_errors(self, question: str, qid: str) -> Answer:
        """Answer dosing error questions."""
        usubjid_match = re.search(r'(042-S\d{2}-\d{3})', question)
        if usubjid_match:
            usubjid = usubjid_match.group(1)
            errors = find_dosing_errors(self.graph, usubjid)
            evidence = [e.ref for e in errors]
            answer = [{'usubjid': usubjid, 'visit': e.parsed.get('visit'), 'dose': e.parsed.get('exdose'), 'date': str(e.parsed.get('exstdtc'))} for e in errors]
            return Answer(qid, answer, evidence, {})
        
        results = []
        evidence = []
        for subj in self.graph.records_by_subject:
            errors = find_dosing_errors(self.graph, subj)
            for e in errors:
                results.append({
                    'usubjid': subj,
                    'visit': e.parsed.get('visit'),
                    'dose': e.parsed.get('exdose'),
                    'date': str(e.parsed.get('exstdtc'))
                })
                evidence.append(e.ref)
        return Answer(qid, results, evidence, {})
    
    def _answer_visit_deviations(self, question: str, qid: str) -> Answer:
        """Answer visit window deviation questions."""
        usubjid_match = re.search(r'(042-S\d{2}-\d{3})', question)
        if usubjid_match:
            usubjid = usubjid_match.group(1)
            protocol_version = self._get_protocol_version(usubjid)
            devs = find_visit_window_deviations(self.graph, usubjid, protocol_version)
            evidence = [d['ref'] for d in devs]
            return Answer(qid, devs, evidence, {})
        
        results = []
        evidence = []
        for subj in self.graph.records_by_subject:
            protocol_version = self._get_protocol_version(subj)
            devs = find_visit_window_deviations(self.graph, subj, protocol_version)
            for d in devs:
                d['usubjid'] = subj
                results.append(d)
                evidence.append(d['ref'])
        return Answer(qid, results, evidence, {})
    
    def _answer_saes(self, question: str, qid: str) -> Answer:
        """Answer SAE questions."""
        usubjid_match = re.search(r'(042-S\d{2}-\d{3})', question)
        if usubjid_match:
            usubjid = usubjid_match.group(1)
            saes = find_saes(self.graph, usubjid)
            evidence = [s.ref for s in saes]
            answer = [{'usubjid': usubjid, 'term': s.parsed.get('aeterm'), 'severity': s.parsed.get('aesev'), 'start': str(s.parsed.get('aestdtc')), 'outcome': s.parsed.get('aeout')} for s in saes]
            return Answer(qid, answer, evidence, {})
        
        saes = find_saes(self.graph)
        evidence = [s.ref for s in saes]
        answer = []
        for s in saes:
            # Find subject
            subj = s.ref.usubjid
            answer.append({
                'usubjid': subj,
                'term': s.parsed.get('aeterm'),
                'severity': s.parsed.get('aesev'),
                'start': str(s.parsed.get('aestdtc')),
                'outcome': s.parsed.get('aeout')
            })
        return Answer(qid, answer, evidence, {})
    
    def _answer_discontinued(self, question: str, qid: str) -> Answer:
        """Answer discontinuation questions."""
        disc = find_discontinued_subjects(self.graph)
        evidence = [d['ref'] for d in disc]
        return Answer(qid, disc, evidence, {})

    def _answer_lab_finding(self, question: str, qid: str) -> Answer:
        """Answer lab value threshold finding questions."""
        question_lower = question.lower()
        
        # Determine test and threshold
        testcd = None
        if 'alt' in question_lower:
            testcd = 'ALT'
        elif 'ast' in question_lower:
            testcd = 'AST'
        elif 'bilirubin' in question_lower or 'bili' in question_lower:
            testcd = 'BILI'
        elif 'hba1c' in question_lower:
            testcd = 'HBA1C'
        elif 'glucose' in question_lower or 'gluc' in question_lower:
            testcd = 'GLUC'
        elif 'creatinine' in question_lower or 'creat' in question_lower:
            testcd = 'CREAT'
        
        # Determine threshold and comparison
        threshold = None
        above = True
        threshold_is_uln = False
        uln_multiplier = None
        
        if '3xuln' in question_lower or '3 x uln' in question_lower or '3×uln' in question_lower:
            threshold_is_uln = True
            uln_multiplier = 3.0
        elif '2xuln' in question_lower or '2 x uln' in question_lower or '2×uln' in question_lower:
            threshold_is_uln = True
            uln_multiplier = 2.0
        elif '1000' in question:
            threshold = 1000.0
        elif '500' in question:
            threshold = 500.0
        elif '300' in question:
            threshold = 300.0
        elif '200' in question:
            threshold = 200.0
        elif '100' in question:
            threshold = 100.0
        elif '50' in question:
            threshold = 50.0
        elif '10' in question:
            threshold = 10.0
        elif '5' in question:
            threshold = 5.0
        
        if testcd is None:
            return self._answer_general(question, qid)
        
        # Check for below/less than
        if any(x in question_lower for x in ['below', 'less', '<', 'low']):
            above = False
        
        results = []
        evidence = []
        for subj, domains in self.graph.records_by_subject.items():
            lb_records = domains.get(Domain.LB, [])
            test_records = [r for r in lb_records if r.parsed.get('lbtestcd') == testcd and r.parsed.get('lborres_std') is not None]
            for r in test_records:
                val = r.parsed['lborres_std']
                matched = False
                if threshold_is_uln:
                    uln = r.parsed.get('ref_high_std')
                    if uln is not None:
                        dynamic_threshold = uln * uln_multiplier
                        if (above and val > dynamic_threshold) or (not above and val < dynamic_threshold):
                            matched = True
                elif threshold is not None:
                    if (above and val > threshold) or (not above and val < threshold):
                        matched = True
                
                if matched:
                    # Use standardized unit
                    std_unit = r.parsed.get('lborresu', '')
                    if r.parsed.get('lbtestcd') in ('ALT', 'AST') and r.parsed.get('lab') == 'S07':
                        std_unit = 'U/L'
                    results.append({
                        'usubjid': subj,
                        'test': testcd,
                        'value': val,
                        'unit': std_unit,
                        'visit': r.parsed.get('visit'),
                        'date': str(r.parsed.get('lbdtc'))
                    })
                    evidence.append(r.ref)
                    break  # One record per subject
        
        if 'how many' in question_lower or 'count' in question_lower:
            return Answer(qid, len(results), evidence, {'subjects': results})
        else:
            return Answer(qid, results, evidence, {})

    def _answer_count_subjects(self, question: str, qid: str) -> Answer:
        """Answer subject count questions."""
        counts = count_subjects_by_arm(self.graph)
        total = sum(counts.values())
        
        if 'drug' in question.lower() and 'placebo' not in question.lower():
            answer = counts['DRUG']
        elif 'placebo' in question.lower():
            answer = counts['PLACEBO']
        else:
            answer = total
        
        # Evidence: all DM records
        evidence = []
        for subj, domains in self.graph.records_by_subject.items():
            dm_records = domains.get(Domain.DM, [])
            if dm_records:
                evidence.append(dm_records[0].ref)
        
        return Answer(qid, answer, evidence, {'by_arm': counts})
    
    def _answer_count_sites(self, question: str, qid: str) -> Answer:
        """Answer site count questions."""
        answer = count_sites(self.graph)
        
        evidence = []
        for subj, domains in self.graph.records_by_subject.items():
            dm_records = domains.get(Domain.DM, [])
            if dm_records:
                evidence.append(dm_records[0].ref)
        
        return Answer(qid, answer, evidence, {})
    
    def _answer_patient360(self, question: str, qid: str) -> Answer:
        """Answer patient360 questions."""
        usubjid_match = re.search(r'(042-S\d{2}-\d{3})', question)
        if not usubjid_match:
            return Answer(qid, {}, [], {})
        
        usubjid = usubjid_match.group(1)
        p360 = self.graph.patient360(usubjid)
        
        # Collect all refs as evidence
        evidence = []
        for domain in [Domain.DM, Domain.AE, Domain.LB, Domain.VS, Domain.EX, Domain.CM, Domain.DS, Domain.MH, Domain.EG]:
            records = self.graph.records_by_subject.get(usubjid, {}).get(domain, [])
            evidence.extend([r.ref for r in records])
        
        return Answer(qid, {
            'usubjid': p360.usubjid,
            'dm': p360.dm,
            'ae_count': len(p360.ae),
            'lb_count': len(p360.lb),
            'vs_count': len(p360.vs),
            'ex_count': len(p360.ex),
            'cm_count': len(p360.cm),
            'ds': p360.ds,
            'mh': p360.mh,
            'eg_count': len(p360.eg)
        }, evidence, {})
    
    def _answer_general(self, question: str, qid: str) -> Answer:
        """Handle general/unrecognized questions."""
        # Try to extract USUBJID and return basic info
        usubjid_match = re.search(r'(042-S\d{2}-\d{3})', question)
        if usubjid_match:
            usubjid = usubjid_match.group(1)
            p360 = self.graph.patient360(usubjid)
            
            evidence = []
            for domain in [Domain.DM, Domain.AE, Domain.LB, Domain.VS, Domain.EX, Domain.CM, Domain.DS, Domain.MH, Domain.EG]:
                records = self.graph.records_by_subject.get(usubjid, {}).get(domain, [])
                evidence.extend([r.ref for r in records])
            
            return Answer(qid, {
                'usubjid': usubjid,
                'found': True,
                'summary': {
                    'dm': p360.dm,
                    'ae_count': len(p360.ae),
                    'lb_count': len(p360.lb),
                    'vs_count': len(p360.vs),
                    'ex_count': len(p360.ex),
                    'cm_count': len(p360.cm),
                    'ds': p360.ds,
                    'mh': p360.mh,
                    'eg_count': len(p360.eg)
                }
            }, evidence, {})
        
        return Answer(qid, "Question not recognized. Please ask about Hy's law, prohibited medications, dosing errors, visit deviations, SAEs, discontinuations, subject counts, site counts, or patient profiles.", [], {})
    
    def _get_protocol_version(self, usubjid: str) -> int:
        """Get protocol version for a subject at current cut."""
        # Use the protocol version from the current cut
        if self.graph._build_cut:
            for cut_info in self.graph.cuts.values():
                if cut_info.get('cut') == self.graph._build_cut:
                    return cut_info.get('protocol_version', 3)
        # Default to latest (v3)
        return 3