"""
Deterministic rule-based reasoning for ATLAS.
"""
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timedelta
from atlas.schemas import Domain, RecordRef
from atlas.graph import StudyGraph, NormalizedRecord


def find_hys_law_candidates(graph: StudyGraph, usubjid: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Find potential Hy's Law cases.
    ALT/AST > 3xULN + Bilirubin > 2xULN within 14 days.
    Exclude sites S03 and S07.
    """
    candidates = []
    
    subjects = [usubjid] if usubjid else list(graph.records_by_subject.keys())
    
    for subj in subjects:
        # Get site
        dm_records = graph.records_by_subject.get(subj, {}).get(Domain.DM, [])
        if not dm_records:
            continue
        siteid = dm_records[0].parsed.get('siteid', '')
        
        # Exclude unreliable sites
        if siteid in ('S03', 'S07'):
            continue
        
        lb_records = graph.records_by_subject.get(subj, {}).get(Domain.LB, [])
        if not lb_records:
            continue
        
        # Group by visit/date
        alt_records = [r for r in lb_records if r.parsed.get('lbtestcd') == 'ALT' and r.parsed.get('lborres_std') is not None]
        ast_records = [r for r in lb_records if r.parsed.get('lbtestcd') == 'AST' and r.parsed.get('lborres_std') is not None]
        bili_records = [r for r in lb_records if r.parsed.get('lbtestcd') == 'BILI' and r.parsed.get('lborres_std') is not None]
        
        # Check each ALT/AST record against bilirubin within 14 days
        for alt_rec in alt_records:
            alt_val = alt_rec.parsed.get('lborres_std')
            alt_uln = alt_rec.parsed.get('ref_high')
            alt_date = alt_rec.parsed.get('lbdtc')
            
            if not all([alt_val, alt_uln, alt_date]):
                continue
            
            if alt_val <= 3 * alt_uln:
                continue
            
            for ast_rec in ast_records:
                ast_val = ast_rec.parsed.get('lborres_std')
                ast_uln = ast_rec.parsed.get('ref_high')
                ast_date = ast_rec.parsed.get('lbdtc')
                
                if not all([ast_val, ast_uln, ast_date]):
                    continue
                
                if ast_val <= 3 * ast_uln:
                    continue
                
                # Check bilirubin within 14 days
                for bili_rec in bili_records:
                    bili_val = bili_rec.parsed.get('lborres_std')
                    bili_uln = bili_rec.parsed.get('ref_high')
                    bili_date = bili_rec.parsed.get('lbdtc')
                    
                    if not all([bili_val, bili_uln, bili_date]):
                        continue
                    
                    if bili_val <= 2 * bili_uln:
                        continue
                    
                    # Check within 14 days
                    if abs((alt_date - bili_date).days) <= 14 or abs((ast_date - bili_date).days) <= 14:
                        candidates.append({
                            'usubjid': subj,
                            'alt_rec': alt_rec,
                            'ast_rec': ast_rec,
                            'bili_rec': bili_rec,
                            'alt_val': alt_val,
                            'ast_val': ast_val,
                            'bili_val': bili_val,
                            'alt_uln': alt_uln,
                            'ast_uln': ast_uln,
                            'bili_uln': bili_uln
                        })
                        break
    
    return candidates


def check_hys_law_exclusions(graph: StudyGraph, candidate: Dict[str, Any]) -> bool:
    """
    Check Hy's law exclusions:
    - Cholestasis (ALP > 2xULN)
    - Alternative explanation (hepatotoxic meds)
    - Baseline transaminases already elevated
    """
    usubjid = candidate['usubjid']
    alt_date = candidate['alt_rec'].parsed.get('lbdtc')
    
    # Check baseline transaminases
    lb_records = graph.records_by_subject.get(usubjid, {}).get(Domain.LB, [])
    screening_alts = [r for r in lb_records if r.parsed.get('lbtestcd') == 'ALT' 
                      and r.parsed.get('visit') == 'SCREENING'
                      and r.parsed.get('lborres_std') is not None]
    screening_asts = [r for r in lb_records if r.parsed.get('lbtestcd') == 'AST' 
                      and r.parsed.get('visit') == 'SCREENING'
                      and r.parsed.get('lborres_std') is not None]
    
    for rec in screening_alts:
        if rec.parsed['lborres_std'] > 2 * rec.parsed.get('ref_high', 0):
            return True  # Excluded - baseline elevated
    
    for rec in screening_asts:
        if rec.parsed['lborres_std'] > 2 * rec.parsed.get('ref_high', 0):
            return True  # Excluded - baseline elevated
    
    # Check cholestasis (ALP > 2xULN around same time)
    alp_records = [r for r in lb_records if r.parsed.get('lbtestcd') == 'ALP' 
                   and r.parsed.get('lborres_std') is not None]
    for rec in alp_records:
        if abs((rec.parsed.get('lbdtc', alt_date) - alt_date).days) <= 14:
            if rec.parsed['lborres_std'] > 2 * rec.parsed.get('ref_high', 0):
                return True  # Excluded - cholestasis
    
    # Check concomitant hepatotoxic medications
    cm_records = graph.records_by_subject.get(usubjid, {}).get(Domain.CM, [])
    hepatotoxic_classes = ['SULFONYLUREA', 'SYSTEMIC_GLUCOCORTICOID']
    for cm in cm_records:
        if cm.parsed.get('cmclas') in hepatotoxic_classes:
            cm_start = cm.parsed.get('cmstdtc')
            if cm_start and cm_start <= alt_date:
                return True  # Excluded - alternative explanation
    
    return False


def get_monitor_decision(graph: StudyGraph, usubjid: str) -> Tuple[str, str]:
    """Get medical monitor decision for a Hy's law candidate."""
    key = f"HYS_LAW_CANDIDATE|{usubjid}"
    if key in graph.monitor_decisions:
        decision = graph.monitor_decisions[key]
        return decision[0], decision[1] if len(decision) > 1 else ""
    
    # Check site-level
    dm_records = graph.records_by_subject.get(usubjid, {}).get(Domain.DM, [])
    if dm_records:
        siteid = dm_records[0].parsed.get('siteid', '')
        site_key = f"HYS_LAW_CANDIDATE|{siteid}"
        if site_key in graph.monitor_decisions:
            decision = graph.monitor_decisions[site_key]
            return decision[0], decision[1] if len(decision) > 1 else ""
    
    return "CLARIFY", "What was the ALT at screening, and is there a concomitant hepatotoxic medication?"


def find_prohibited_meds(graph: StudyGraph, usubjid: str, protocol_version: int = 3) -> List[NormalizedRecord]:
    """Find prohibited concomitant medications per protocol version."""
    prohibited = ['SULFONYLUREA', 'SYSTEMIC_GLUCOCORTICOID'] if protocol_version >= 3 else ['SYSTEMIC_GLUCOCORTICOID']
    
    cm_records = graph.records_by_subject.get(usubjid, {}).get(Domain.CM, [])
    return [r for r in cm_records if r.parsed.get('cmclas') in prohibited]


def find_dosing_errors(graph: StudyGraph, usubjid: str) -> List[NormalizedRecord]:
    """Find dosing errors (dose != 10mg drug or != 0mg placebo)."""
    dm_records = graph.records_by_subject.get(usubjid, {}).get(Domain.DM, [])
    if not dm_records:
        return []
    
    arm = dm_records[0].parsed.get('arm', '')
    ex_records = graph.records_by_subject.get(usubjid, {}).get(Domain.EX, [])
    
    errors = []
    for ex in ex_records:
        dose = ex.parsed.get('exdose')
        if arm == 'DRUG' and dose != 10:
            errors.append(ex)
        elif arm == 'PLACEBO' and dose != 0:
            errors.append(ex)
    return errors


def find_visit_window_deviations(graph: StudyGraph, usubjid: str, protocol_version: int = 3) -> List[Dict[str, Any]]:
    """Find visits outside protocol window."""
    # Visit schedule: Screening (Day -14), Baseline (Day 0), Weeks 2,4,8,12,16,20,24, EOS (Day 182)
    # Window: ±3 days for v2/v3, ±7 days for v1
    window = 3 if protocol_version >= 2 else 7
    
    visit_days = {
        'SCREENING': -14,
        'BASELINE': 0,
        'WEEK2': 14,
        'WEEK4': 28,
        'WEEK8': 56,
        'WEEK12': 84,
        'WEEK16': 112,
        'WEEK20': 140,
        'WEEK24': 168,
        'EOS': 182
    }
    
    dm_records = graph.records_by_subject.get(usubjid, {}).get(Domain.DM, [])
    if not dm_records:
        return []
    
    rfstdtc = dm_records[0].parsed.get('rfstdtc')
    if not rfstdtc:
        return []
    
    deviations = []
    for domain in [Domain.VS, Domain.LB, Domain.EG, Domain.EX]:
        records = graph.records_by_subject.get(usubjid, {}).get(domain, [])
        for r in records:
            visit = r.parsed.get('visit')
            if not visit or visit not in visit_days:
                continue
            r_date = r.parsed.get('lbdtc') or r.parsed.get('vsdtc') or r.parsed.get('egdtc') or r.parsed.get('exstdtc')
            if not r_date:
                continue
            expected = rfstdtc + timedelta(days=visit_days[visit])
            if abs((r_date - expected).days) > window:
                deviations.append({
                    'domain': domain.value,
                    'visit': visit,
                    'expected': expected,
                    'actual': r_date,
                    'deviation_days': abs((r_date - expected).days),
                    'ref': r.ref
                })
    return deviations


def find_saes(graph: StudyGraph, usubjid: Optional[str] = None) -> List[NormalizedRecord]:
    """Find serious adverse events (AESER=Y or AESHOSP=Y)."""
    subjects = [usubjid] if usubjid else list(graph.records_by_subject.keys())
    saes = []
    for subj in subjects:
        ae_records = graph.records_by_subject.get(subj, {}).get(Domain.AE, [])
        for ae in ae_records:
            if ae.parsed.get('is_serious'):
                saes.append(ae)
    return saes


def count_subjects_by_arm(graph: StudyGraph) -> Dict[str, int]:
    """Count subjects by treatment arm."""
    counts = {'DRUG': 0, 'PLACEBO': 0}
    for subj, domains in graph.records_by_subject.items():
        dm_records = domains.get(Domain.DM, [])
        if dm_records:
            arm = dm_records[0].parsed.get('arm', '')
            if arm in counts:
                counts[arm] += 1
    return counts


def count_sites(graph: StudyGraph) -> int:
    """Count unique sites."""
    sites = set()
    for subj, domains in graph.records_by_subject.items():
        dm_records = domains.get(Domain.DM, [])
        if dm_records:
            site = dm_records[0].parsed.get('siteid', '')
            if site:
                sites.add(site)
    return len(sites)


def find_discontinued_subjects(graph: StudyGraph) -> List[Dict[str, Any]]:
    """Find discontinued subjects with reasons."""
    results = []
    for subj, domains in graph.records_by_subject.items():
        ds_records = domains.get(Domain.DS, [])
        for ds in ds_records:
            if ds.parsed.get('dsdecod') == 'DISCONTINUED':
                results.append({
                    'usubjid': subj,
                    'reason': ds.parsed.get('dsterm', ''),
                    'date': ds.parsed.get('dsstdtc'),
                    'ref': ds.ref
                })
    return results